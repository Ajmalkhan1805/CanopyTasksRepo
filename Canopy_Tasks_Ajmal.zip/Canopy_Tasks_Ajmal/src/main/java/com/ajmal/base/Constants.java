package com.ajmal.base;

/**
 * @author ajimulkhan
 *
 */

public class Constants {
	
	/***Global Constants***/
	public static final String browser = "chrome";
	public static final String testsiteurl = "https://dev-engine.kurtosys.org";
	public static long implicitwait=10;
	public static final String userName = "at_042";
	public static final String password = "TechGeek$123";
	
}
