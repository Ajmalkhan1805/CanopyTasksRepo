package com.ajmal.rough;



import com.ajmal.base.Page;
import com.ajmal.pages.actions.SigninPage;
import com.ajmal.utilities.Utilities;

/**
 * @author ajimulkhan
 * 
 *  @Desc	This class is used to do rough works
 *
 */
public class SignInTest {

	
	public static void main(String[] args) throws Exception {

	
	}
}
